package uz.alifbo.klaviatura

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class UzKeyboardService : InputMethodService() {

    private val handler = Handler(Looper.getMainLooper())
    private var container: FrameLayout? = null
    private var column: LinearLayout? = null
    private var bubble: TextView? = null

    private var shift = false
    private var caps = false
    private var symbols = false
    private var lastShiftTap = 0L
    private var repeatRunnable: Runnable? = null
    private val letterKeys = mutableListOf<Pair<TextView, String>>()
    private var shiftKey: TextView? = null
    private var clipMode = false
    private val clips = ArrayList<String>()
    private var lpRunnable: Runnable? = null

    // sozlamalar
    private var vibrate = true
    private var sound = false
    private var preview = true
    private var autoCap = true
    private var keyHdp = 48

    // ranglar
    private var cBg = 0
    private var cKey = 0
    private var cSpecial = 0
    private var cPressed = 0
    private var cText = 0
    private var cBubble = 0
    private val cShift = Color.parseColor("#2F81F7")
    private val cCaps = Color.parseColor("#1F6FEB")

    private val totalWeight = 11f
    private val tutuq = "\u02BC"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun loadSettings() {
        val p = getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
        vibrate = p.getBoolean(Prefs.VIBRATE, true)
        sound = p.getBoolean(Prefs.SOUND, false)
        preview = p.getBoolean(Prefs.PREVIEW, true)
        autoCap = p.getBoolean(Prefs.AUTOCAP, true)
        keyHdp = when (p.getInt(Prefs.HEIGHT, 1)) {
            0 -> 42
            2 -> 54
            else -> 48
        }
        if (p.getInt(Prefs.THEME, 0) == 1) {
            cBg = Color.parseColor("#D3D6DB")
            cKey = Color.parseColor("#FFFFFF")
            cSpecial = Color.parseColor("#AEB4BD")
            cPressed = Color.parseColor("#8D96A1")
            cText = Color.parseColor("#1F2328")
            cBubble = Color.parseColor("#FFFFFF")
        } else {
            cBg = Color.parseColor("#1F2328")
            cKey = Color.parseColor("#3A4048")
            cSpecial = Color.parseColor("#2A2F36")
            cPressed = Color.parseColor("#5C6670")
            cText = Color.WHITE
            cBubble = Color.parseColor("#E6EDF3")
        }
    }

    override fun onCreate() {
        super.onCreate()
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.addPrimaryClipChangedListener { refreshClip() }
        } catch (e: Exception) {
        }
    }

    private fun addClip(t: String) {
        clips.remove(t)
        clips.add(0, t)
        while (clips.size > 8) clips.removeAt(clips.size - 1)
    }

    private fun refreshClip() {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val d = cm.primaryClip
            if (d != null && d.itemCount > 0) {
                val t = d.getItemAt(0).coerceToText(this)?.toString()
                if (!t.isNullOrBlank()) addClip(t)
            }
        } catch (e: Exception) {
        }
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        loadSettings()
        val c = FrameLayout(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(
            col,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        val b = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
            visibility = View.GONE
            elevation = dp(6).toFloat()
        }
        c.addView(b, FrameLayout.LayoutParams(dp(52), dp(50)))
        container = c
        column = col
        bubble = b
        render()
        return c
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        symbols = false
        clipMode = false
        caps = false
        shift = false
        if (container != null) {
            loadSettings()
            render()
        }
        updateAutoShift()
    }

    // ---------- UI qurish ----------

    private fun render() {
        val c = container ?: return
        val col = column ?: return
        val b = bubble ?: return

        c.setBackgroundColor(cBg)
        col.setPadding(dp(3), dp(6) + (if (preview && !clipMode) dp(46) else 0), dp(3), dp(8))
        b.visibility = View.GONE
        b.setTextColor(Color.parseColor("#1F2328"))
        b.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(cBubble)
        }

        col.removeAllViews()
        letterKeys.clear()
        shiftKey = null

        if (clipMode) {
            refreshClip()
            if (clips.isEmpty()) {
                col.addView(TextView(this).apply {
                    text = "Bufer bo'sh. Biror matndan nusxa oling."
                    setTextColor(cText)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                    setPadding(dp(8), dp(16), dp(8), dp(16))
                })
            }
            clips.take(5).forEach { t -> col.addView(clipItem(t)) }
            val back = makeKey("ABC", 1f, { cSpecial }, 15f) {
                clipMode = false
                render()
            }
            val clear = makeKey("Tozalash", 1f, { cSpecial }, 14f) {
                clips.clear()
                render()
            }
            col.addView(row(listOf(back, clear)))
            return
        }

        if (symbols) {
            col.addView(charRow("1234567890".map { it.toString() }, false))
            col.addView(charRow("@#$%&-+()/".map { it.toString() }, false))
            col.addView(charRow(listOf("*", "\"", "'", ":", ";", "!", "?", "=", "_", "c", "\u0441"), false))
            col.addView(
                row(
                    charKeys(listOf("~", "<", ">", "[", "]", "{", "}", "\\", "|"), false) +
                        backspaceKey(2f)
                )
            )
        } else {
            col.addView(charRow("1234567890".map { it.toString() }, false))
            col.addView(charRow(listOf("q", "ö", "e", "r", "t", "y", "u", "i", "o", "p", "ğ"), true))
            col.addView(charRow(listOf("a", "s", "d", "f", "g", "h", "j", "k", "l", "ş"), true))
            val sk = makeKey("⇧", 2f, { if (caps) cCaps else if (shift) cShift else cSpecial }) { onShift() }
            shiftKey = sk
            col.addView(
                row(
                    listOf<View>(sk) +
                        charKeys(listOf("z", "x", "ç", "v", "b", "n", "m"), true) +
                        backspaceKey(2f)
                )
            )
        }

        val toggle = makeKey(if (symbols) "ABC" else "?123", 1.5f, { cSpecial }, 15f) {
            symbols = !symbols
            render()
        }
        val globe = makeKey("🌐", 1f, { cSpecial }, 16f) {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        val tut = makeKey(tutuq, 1f, { cKey }, preview = true) { typeText(tutuq, false) }
        val comma = makeKey(",", 1f, { cKey }, preview = true) { typeText(",", false) }
        val clip = makeKey("📋", 1f, { cSpecial }, 16f) {
            clipMode = true
            render()
        }
        val space = makeKey("O'zbek", 2.5f, { cKey }, 13f) {
            currentInputConnection?.commitText(" ", 1)
            updateAutoShift()
        }
        val dot = makeKey(".", 1f, { cKey }, preview = true) { typeText(".", false) }
        val enter = makeKey("⏎", 2f, { cSpecial }) { handleEnter() }
        col.addView(row(listOf(toggle, globe, clip, tut, comma, space, dot, enter)))

        refreshLetters()
    }

    private fun row(views: List<View>): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        views.forEach { addView(it) }
    }

    private fun spacer(w: Float): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, w)
    }

    private fun charKeys(chars: List<String>, letter: Boolean): List<View> =
        chars.map { c ->
            val key = makeKey(c, 1f, { cKey }, preview = true, longPress = if (c == "ç") "c" else null) { typeText(c, letter) }
            if (letter) letterKeys.add(key to c)
            key
        }

    private fun charRow(chars: List<String>, letter: Boolean): LinearLayout {
        val pad = (totalWeight - chars.size) / 2f
        val views = mutableListOf<View>()
        if (pad > 0f) views.add(spacer(pad))
        views.addAll(charKeys(chars, letter))
        if (pad > 0f) views.add(spacer(pad))
        return row(views)
    }

    private fun backspaceKey(w: Float): View =
        makeKey("⌫", w, { cSpecial }, 20f, repeat = true) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            updateAutoShift()
        }

    private fun keyBg(color: Int) = GradientDrawable().apply {
        cornerRadius = dp(6).toFloat()
        setColor(color)
    }

    private fun makeKey(
        label: String,
        weight: Float,
        idle: () -> Int,
        textSp: Float = 20f,
        repeat: Boolean = false,
        preview: Boolean = false,
        longPress: String? = null,
        onPress: () -> Unit
    ): TextView {
        val tv = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(cText)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
            background = keyBg(idle())
            layoutParams = LinearLayout.LayoutParams(0, dp(keyHdp), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
        }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.background = keyBg(cPressed)
                    if (vibrate) {
                        v.performHapticFeedback(
                            HapticFeedbackConstants.KEYBOARD_TAP,
                            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                        )
                    }
                    if (sound) {
                        (getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                            .playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
                    }
                    val upNow = shift || caps
                    if (preview) showBubble(tv)
                    onPress()
                    if (longPress != null) {
                        cancelLongPress()
                        val lp = Runnable {
                            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                            val alt = if (upNow) longPress.uppercase() else longPress
                            currentInputConnection?.commitText(alt, 1)
                            bubble?.text = alt
                            updateAutoShift()
                        }
                        lpRunnable = lp
                        handler.postDelayed(lp, 450)
                    }
                    if (repeat) startRepeat(onPress)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    stopRepeat()
                    cancelLongPress()
                    hideBubble()
                    v.background = keyBg(idle())
                }
            }
            true
        }
        return tv
    }

    private fun showBubble(key: TextView) {
        if (!this.preview) return
        val c = container ?: return
        val b = bubble ?: return
        val kl = IntArray(2)
        val cl = IntArray(2)
        key.getLocationInWindow(kl)
        c.getLocationInWindow(cl)
        val bw = dp(52)
        val bh = dp(50)
        var x = kl[0] - cl[0] + (key.width - bw) / 2
        x = x.coerceIn(0, maxOf(0, c.width - bw))
        var y = kl[1] - cl[1] - bh - dp(2)
        if (y < 0) y = 0
        b.text = key.text
        b.translationX = x.toFloat()
        b.translationY = y.toFloat()
        b.visibility = View.VISIBLE
        b.bringToFront()
    }

    private fun cancelLongPress() {
        lpRunnable?.let { handler.removeCallbacks(it) }
        lpRunnable = null
    }

    private fun clipItem(t: String): TextView = TextView(this).apply {
        text = t.replace("\n", " ")
        setTextColor(cText)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), 0, dp(12), 0)
        background = keyBg(cKey)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(keyHdp)).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        setOnClickListener {
            clipMode = false
            render()
            currentInputConnection?.commitText(t, 1)
            updateAutoShift()
        }
    }

    private fun hideBubble() {
        bubble?.visibility = View.GONE
    }

    private fun startRepeat(action: () -> Unit) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 50)
            }
        }
        repeatRunnable = r
        handler.postDelayed(r, 400)
    }

    private fun stopRepeat() {
        repeatRunnable?.let { handler.removeCallbacks(it) }
        repeatRunnable = null
    }

    // ---------- Mantiq ----------

    private fun refreshLetters() {
        val up = shift || caps
        letterKeys.forEach { (tv, base) -> tv.text = if (up) base.uppercase() else base }
        shiftKey?.apply {
            text = if (caps) "⇪" else "⇧"
            background = keyBg(if (caps) cCaps else if (shift) cShift else cSpecial)
        }
    }

    private fun updateAutoShift() {
        if (!caps && autoCap) {
            val ic = currentInputConnection
            val ei = currentInputEditorInfo
            shift = if (ic != null && ei != null &&
                (ei.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT
            ) {
                ic.getCursorCapsMode(ei.inputType) != 0
            } else {
                false
            }
        }
        refreshLetters()
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        if (caps) {
            caps = false
            shift = false
        } else if (shift && now - lastShiftTap < 400) {
            caps = true
        } else {
            shift = !shift
        }
        lastShiftTap = now
        refreshLetters()
    }

    private fun typeText(s: String, letter: Boolean) {
        val out = if (letter && (shift || caps)) s.uppercase() else s
        currentInputConnection?.commitText(out, 1)
        if (shift && !caps) shift = false
        updateAutoShift()
    }

    private fun handleEnter() {
        val ei = currentInputEditorInfo
        val opts = ei?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnter = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (ei != null && !noEnter &&
            action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateAutoShift()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        stopRepeat()
        cancelLongPress()
        hideBubble()
        super.onFinishInputView(finishingInput)
    }
}
