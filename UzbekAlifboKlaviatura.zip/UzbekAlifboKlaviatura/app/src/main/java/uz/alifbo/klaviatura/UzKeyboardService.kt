package uz.alifbo.klaviatura

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView

class UzKeyboardService : InputMethodService() {

    private val handler = Handler(Looper.getMainLooper())
    private var root: LinearLayout? = null
    private var shift = false
    private var caps = false
    private var symbols = false
    private var lastShiftTap = 0L
    private var repeatRunnable: Runnable? = null
    private val letterKeys = mutableListOf<Pair<TextView, String>>()
    private var shiftKey: TextView? = null

    private val cBg = Color.parseColor("#1F2328")
    private val cKey = Color.parseColor("#3A4048")
    private val cSpecial = Color.parseColor("#2A2F36")
    private val cPressed = Color.parseColor("#5C6670")
    private val cShift = Color.parseColor("#2F81F7")
    private val cCaps = Color.parseColor("#1F6FEB")

    private val totalWeight = 11f
    private val tutuq = "\u02BC"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
            setPadding(dp(3), dp(6), dp(3), dp(8))
        }
        root = r
        render()
        return r
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        symbols = false
        caps = false
        shift = false
        if (root != null) render()
        updateAutoShift()
    }

    // ---------- UI qurish ----------

    private fun render() {
        val r = root ?: return
        r.removeAllViews()
        letterKeys.clear()
        shiftKey = null

        if (symbols) {
            r.addView(charRow("1234567890".map { it.toString() }, false))
            r.addView(charRow("@#$%&-+()/".map { it.toString() }, false))
            r.addView(charRow(listOf("*", "\"", "'", ":", ";", "!", "?", "=", "_"), false))
            r.addView(
                row(
                    charKeys(listOf("~", "<", ">", "[", "]", "{", "}", "\\", "|"), false) +
                        backspaceKey(2f)
                )
            )
        } else {
            r.addView(charRow("1234567890".map { it.toString() }, false))
            r.addView(charRow(listOf("q", "ö", "e", "r", "t", "y", "u", "i", "o", "p", "ğ"), true))
            r.addView(charRow(listOf("a", "s", "d", "f", "g", "h", "j", "k", "l", "ş"), true))
            val sk = makeKey("⇧", 2f, { if (caps) cCaps else if (shift) cShift else cSpecial }) { onShift() }
            shiftKey = sk
            r.addView(
                row(
                    listOf<View>(sk) +
                        charKeys(listOf("z", "x", "ç", "v", "b", "n", "m"), true) +
                        backspaceKey(2f)
                )
            )
        }

        val toggle = makeKey(if (symbols) "ABC" else "?123", 1.5f, { cSpecial }, 15f) {
            symbols = !symbols
            render()
        }
        val globe = makeKey("🌐", 1f, { cSpecial }, 16f) {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        val tut = makeKey(tutuq, 1f, { cKey }) { typeText(tutuq, false) }
        val comma = makeKey(",", 1f, { cKey }) { typeText(",", false) }
        val space = makeKey("O'zbek", 3.5f, { cKey }, 13f) {
            currentInputConnection?.commitText(" ", 1)
            updateAutoShift()
        }
        val dot = makeKey(".", 1f, { cKey }) { typeText(".", false) }
        val enter = makeKey("⏎", 2f, { cSpecial }) { handleEnter() }
        r.addView(row(listOf(toggle, globe, tut, comma, space, dot, enter)))

        refreshLetters()
    }

    private fun row(views: List<View>): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        views.forEach { addView(it) }
    }

    private fun spacer(w: Float): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, w)
    }

    private fun charKeys(chars: List<String>, letter: Boolean): List<View> =
        chars.map { c ->
            val key = makeKey(c, 1f, { cKey }) { typeText(c, letter) }
            if (letter) letterKeys.add(key to c)
            key
        }

    private fun charRow(chars: List<String>, letter: Boolean): LinearLayout {
        val pad = (totalWeight - chars.size) / 2f
        val views = mutableListOf<View>()
        if (pad > 0f) views.add(spacer(pad))
        views.addAll(charKeys(chars, letter))
        if (pad > 0f) views.add(spacer(pad))
        return row(views)
    }

    private fun backspaceKey(w: Float): View =
        makeKey("⌫", w, { cSpecial }, 20f, repeat = true) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            updateAutoShift()
        }

    private fun keyBg(color: Int) = GradientDrawable().apply {
        cornerRadius = dp(6).toFloat()
        setColor(color)
    }

    private fun makeKey(
        label: String,
        weight: Float,
        idle: () -> Int,
        textSp: Float = 20f,
        repeat: Boolean = false,
        onPress: () -> Unit
    ): TextView {
        val tv = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
            background = keyBg(idle())
            layoutParams = LinearLayout.LayoutParams(0, dp(48), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
        }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.background = keyBg(cPressed)
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    onPress()
                    if (repeat) startRepeat(onPress)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    stopRepeat()
                    v.background = keyBg(idle())
                }
            }
            true
        }
        return tv
    }

    private fun startRepeat(action: () -> Unit) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 50)
            }
        }
        repeatRunnable = r
        handler.postDelayed(r, 400)
    }

    private fun stopRepeat() {
        repeatRunnable?.let { handler.removeCallbacks(it) }
        repeatRunnable = null
    }

    // ---------- Mantiq ----------

    private fun refreshLetters() {
        val up = shift || caps
        letterKeys.forEach { (tv, base) -> tv.text = if (up) base.uppercase() else base }
        shiftKey?.apply {
            text = if (caps) "⇪" else "⇧"
            background = keyBg(if (caps) cCaps else if (shift) cShift else cSpecial)
        }
    }

    private fun updateAutoShift() {
        if (!caps) {
            val ic = currentInputConnection
            val ei = currentInputEditorInfo
            shift = if (ic != null && ei != null &&
                (ei.inputType and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT
            ) {
                ic.getCursorCapsMode(ei.inputType) != 0
            } else {
                false
            }
        }
        refreshLetters()
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        if (caps) {
            caps = false
            shift = false
        } else if (shift && now - lastShiftTap < 400) {
            caps = true
        } else {
            shift = !shift
        }
        lastShiftTap = now
        refreshLetters()
    }

    private fun typeText(s: String, letter: Boolean) {
        val out = if (letter && (shift || caps)) s.uppercase() else s
        currentInputConnection?.commitText(out, 1)
        if (shift && !caps) shift = false
        updateAutoShift()
    }

    private fun handleEnter() {
        val ei = currentInputEditorInfo
        val opts = ei?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noEnter = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (ei != null && !noEnter &&
            action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED
        ) {
            currentInputConnection?.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
        updateAutoShift()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        stopRepeat()
        super.onFinishInputView(finishingInput)
    }
}
