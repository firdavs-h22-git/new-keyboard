package uz.alifbo.klaviatura

object Prefs {
    const val NAME = "uzkb"
    const val VIBRATE = "vibrate"
    const val SOUND = "sound"
    const val PREVIEW = "preview"
    const val AUTOCAP = "autocap"
    const val HEIGHT = "height"   // 0 past, 1 o'rta, 2 baland
    const val THEME = "theme"     // 0 qorong'i, 1 yorug'
}
