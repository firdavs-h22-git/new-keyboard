package uz.alifbo.klaviatura

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, sp: Float, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(12), 0, dp(4))
    }

    private fun sw(title: String, key: String, def: Boolean) = Switch(this).apply {
        text = title
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        isChecked = prefs.getBoolean(key, def)
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
    }

    private fun choice(options: List<String>, current: Int, onPick: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(this)
        g.orientation = RadioGroup.HORIZONTAL
        options.forEachIndexed { i, t ->
            val rb = RadioButton(this)
            rb.text = t
            rb.id = 1000 + i
            g.addView(rb)
        }
        g.check(1000 + current)
        g.setOnCheckedChangeListener { _, id -> onPick(id - 1000) }
        return g
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }

        col.addView(label("Yangi alifbo klaviaturasi", 24f, true))
        col.addView(label("Ö  Ğ  Ş  Ç harflari bitta tugma bilan yoziladi.", 16f))

        col.addView(Button(this).apply {
            text = "1. Klaviaturani yoqish"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "2. Klaviaturani tanlash"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        col.addView(EditText(this).apply { hint = "Bu yerda sinab ko'ring" })

        // ---- Sozlamalar ----
        col.addView(label("Sozlamalar", 20f, true))
        col.addView(sw("Tugma bosilganda harf tepada ko'rinsin", Prefs.PREVIEW, true))
        col.addView(sw("Tebranish", Prefs.VIBRATE, true))
        col.addView(sw("Tugma ovozi", Prefs.SOUND, false))
        col.addView(sw("Gap boshida avtomatik katta harf", Prefs.AUTOCAP, true))

        col.addView(label("Klaviatura balandligi", 16f))
        col.addView(choice(listOf("Past", "O'rta", "Baland"), prefs.getInt(Prefs.HEIGHT, 1)) {
            prefs.edit().putInt(Prefs.HEIGHT, it).apply()
        })
        col.addView(label("Klaviatura rangi", 16f))
        col.addView(choice(listOf("Qorong'i", "Yorug'"), prefs.getInt(Prefs.THEME, 0)) {
            prefs.edit().putInt(Prefs.THEME, it).apply()
        })
        col.addView(TextView(this).apply {
            text = "O'zgarishlar klaviatura keyingi safar ochilganda kuchga kiradi."
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(8), 0, dp(8))
        })

        // ---- O'giruvchi ----
        col.addView(label("Eski alifbodan yangisiga o'girish", 20f, true))
        val input = EditText(this).apply {
            hint = "Eski alifbodagi matnni shu yerga qo'ying (o', g', sh, ch)"
            minLines = 4
            gravity = Gravity.TOP
        }
        col.addView(input)

        val output = TextView(this).apply {
            setTextIsSelectable(true)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            minLines = 4
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }

        col.addView(Button(this).apply {
            text = "O'girish"
            setOnClickListener { output.text = Converter.toNew(input.text.toString()) }
        })
        col.addView(output)
        col.addView(Button(this).apply {
            text = "Nusxa olish"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("alifbo", output.text.toString()))
                Toast.makeText(this@MainActivity, "Nusxa olindi", Toast.LENGTH_SHORT).show()
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
