package uz.alifbo.klaviatura

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String, sp: Float, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(4))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }

        col.addView(label("Yangi alifbo klaviaturasi", 24f, true))
        col.addView(label("Ö  Ğ  Ş  Ç harflari bitta tugma bilan yoziladi.", 16f))

        col.addView(Button(this).apply {
            text = "1. Klaviaturani yoqish"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "2. Klaviaturani tanlash"
            setOnClickListener {
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        col.addView(EditText(this).apply { hint = "Bu yerda sinab ko'ring" })

        col.addView(label("Eski alifbodan yangisiga o'girish", 18f, true))
        val input = EditText(this).apply {
            hint = "Eski alifbodagi matnni shu yerga qo'ying (o', g', sh, ch)"
            minLines = 4
            gravity = Gravity.TOP
        }
        col.addView(input)

        val output = TextView(this).apply {
            setTextIsSelectable(true)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            minLines = 4
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }

        col.addView(Button(this).apply {
            text = "O'girish"
            setOnClickListener { output.text = Converter.toNew(input.text.toString()) }
        })
        col.addView(output)
        col.addView(Button(this).apply {
            text = "Nusxa olish"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("alifbo", output.text.toString()))
                Toast.makeText(this@MainActivity, "Nusxa olindi", Toast.LENGTH_SHORT).show()
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
