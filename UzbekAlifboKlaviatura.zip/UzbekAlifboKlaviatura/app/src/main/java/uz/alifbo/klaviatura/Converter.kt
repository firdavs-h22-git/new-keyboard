package uz.alifbo.klaviatura

/** Eski lotin alifbosidagi matnni yangi alifboga (Ö Ğ Ş Ç) o'giradi. */
object Converter {
    private const val APOS = "'\u2019\u2018\u02BB\u02BC`\u00B4\u02B9"

    private val reOG = Regex("([oOgG])[$APOS]")
    private val reShCh = Regex("([sScC])([hH])")
    private val reTutuq = Regex("(?<=\\p{L})[$APOS](?=\\p{L})")

    fun toNew(text: String): String {
        var s = reOG.replace(text) { m ->
            when (m.groupValues[1]) {
                "o" -> "ö"
                "O" -> "Ö"
                "g" -> "ğ"
                else -> "Ğ"
            }
        }
        s = reShCh.replace(s) { m ->
            val first = m.groupValues[1]
            val upper = first[0].isUpperCase()
            if (first.equals("s", ignoreCase = true)) {
                if (upper) "Ş" else "ş"
            } else {
                if (upper) "Ç" else "ç"
            }
        }
        s = reTutuq.replace(s, "\u02BC")
        return s
    }
}
