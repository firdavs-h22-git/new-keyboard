# Yangi alifbo klaviaturasi (Ö Ğ Ş Ç)

Android klaviatura + eski alifbodan yangisiga o'giruvchi.

1. GitHub'ga yuklang (main branch).
2. Actions -> "Build APK" -> tugagach Artifacts'dan `app-debug.apk` ni yuklab oling.
3. Ilovani o'rnating, ochib "Klaviaturani yoqish" va "Klaviaturani tanlash" tugmalarini bosing.
